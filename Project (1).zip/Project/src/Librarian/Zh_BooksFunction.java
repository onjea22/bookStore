package Librarian;

public abstract class Zh_BooksFunction {

	public abstract String getBname();
	public abstract long getBprice();
	public abstract long getIBSN();
	public abstract int getBquantity();
}

