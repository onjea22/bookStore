package Librarian;

public enum Zh_Genre {

	MYSTRERY, ACTION, HISTORICAL, DYSTOPIAN, FANTASY 
}
