package Librarian;

import java.io.Serializable;

public enum Zh_accessLevel implements Serializable {
LIBRARIAN,
MANAGER,
ADMINISTRATOR
}
