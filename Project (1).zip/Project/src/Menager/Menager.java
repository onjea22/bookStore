package Menager;

public class Menager {

}
